// JavaScript Document
$(document).ready(function(){
	var idcount = 0;
	$("#studentform").submit(function(event){
		event.preventDefault();
		idcount++;
		var Name = $("#name").val();
        var Surname = $("#surname").val();
		var Gender = $("#gender:checked").val();
        var Address = $("#address").val();
        var Email = $("#email").val();
        var Number = $("#number").val();
		$("#tblData tbody").append("<tr><td>" + idcount + "</td>" +
								     "<td>" + Name + "</td>" +
                                     "<td>" + Surname + "</td>" +
								     "<td>" + Gender + "</td>" +
                                    "<td>" + Address + "</td>" +
                                     "<td>" + Email + "</td>" +
                                   "<td>" + Number + "</td>" +
								    "<td><button class='btnEdit'>Edit</button>" +
								  "<button class='btnDelete'>Delete</button></td></tr>")
		$(".btnEdit").bind("click", Edit);
		$(".btnDelete").bind("click", Delete);
	});

function Save() {
	var par = $(this).parent().parent();
	var tdName = par.children("td:nth-child(2)");
    var tdSurname = par.children("td:nth-child(3)");
	var tdGender = par.children("td:nth-child(4)");
    var tdAddress = par.children("td:nth-child(5)");
    var tdEmail = par.children("td:nth-child(6)");
    var tdNumber = par.children("td:nth-child(7)");
	var tdButtons = par.children("td:nth-child(8)");
	
	tdName.html(tdName.children("input[type=text]").val());
    tdSurname.html(tdSurname.children("input[type=text]").val());
	tdGender.html(tdGender.children("input[type=text]").val());
    tdAddress.html(tdAddress.children("input[type=text]").val());
    tdEmail.html(tdEmail.children("input[type=text]").val());
    tdNumber.html(tdNumber.children("input[type=text]").val());
	tdButtons.html("<button class='btnEdit'>Edit</button>" + "<button class='btnDelete'>Delete</button>");
	$(".btnEdit").bind("click", Edit);
    $(".btnDelete").bind("click", Delete);
	
}

function Edit () {
	var par = $(this).parent().parent();
	var tdName = par.children("td:nth-child(2)");
    var tdSurname = par.children("td:nth-child(3)");
	var tdGender = par.children("td:nth-child(4)");
    var tdAddress = par.children("td:nth-child(5)");
    var tdEmail = par.children("td:nth-child(6)");
    var tdNumber = par.children("td:nth-child(7)");
	var tdButtons = par.children("td:nth-child(8)");
	
	
	tdName.html("<input type='text' value= '" +
			   tdName.html() + "'>");
    tdSurname.html("<input type='text' value=' " +
					tdSurname.html() + "'>");
	tdGender.html("<input type='text' value= '" +
				 tdGender.html() + "'>");
    tdAddress.html("<input type='text' value= '" +
				 tdAddress.html() + "'>");
    tdEmail.html("<input type='text' value= '" +
				 tdEmail.html() + "'>");
    tdNumber.html("<input type='text' value= '" +
				 tdNumber.html() + "'>");
	tdButtons.html("<button class='btnSave'>Save</button>");
	
	$(".btnSave").bind("click" , Save);
}
			

function Delete(){
	var par = $(this).parent().parent(); // this will select tr
	par.remove();
}
	    
});
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function CancelStudent(){
		window.location.reload();
}